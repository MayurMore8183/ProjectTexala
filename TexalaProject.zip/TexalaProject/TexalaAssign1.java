package com.jsp.Project;

import java.util.Scanner;

public class TexalaAssign1 {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the URL to read html");
		String URL = scan.nextLine();

		Service service = new Service();
		String output1 = service.readHTML(URL);
		System.out.println(output1);
	}
	
	
}