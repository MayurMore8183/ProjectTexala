package com.jsp.Project;

import java.io.File;
import java.io.FileWriter;
import java.net.URL;
import java.net.URLConnection;
import java.util.Scanner;

public class Service {
	
	
	public String readHTML(String link) {
		String content = null;
		URLConnection connection = null;
		try {
		  connection =  new URL(link).openConnection();
		  Scanner scanner = new Scanner(connection.getInputStream());
		  scanner.useDelimiter("\\Z");
		  content = scanner.next();
		  scanner.close();
		  File file = new File("web-context.txt");
		  file.createNewFile();
		  FileWriter fileWriter=new FileWriter(file);
		  fileWriter.write(content);
		  fileWriter.flush();
		  fileWriter.close();
		}catch ( Exception ex ) {
			System.out.println("connection is not getting establish")
		   
		}
		return content;
	}
}
